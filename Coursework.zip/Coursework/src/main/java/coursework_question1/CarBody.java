package coursework_question1;

public enum CarBody {


	MICRO, SEDAN, HATCHBACK, ROADSTER, PICKUP, VAN, COUPE, SUPERCAR, CABRIOLET;

}
