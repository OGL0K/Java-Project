package coursework_question1;

public enum Condition {
	
	NEW, USED;
}
