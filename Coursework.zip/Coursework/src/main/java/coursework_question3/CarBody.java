package coursework_question3;

public enum CarBody {


	MICRO, SEDAN, HATCHBACK, ROADSTER, PICKUP, VAN, COUPE, SUPERCAR, CABRIOLET;

}
