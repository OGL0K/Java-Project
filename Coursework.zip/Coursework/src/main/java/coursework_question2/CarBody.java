package coursework_question2;

public enum CarBody {


	MICRO, SEDAN, HATCHBACK, ROADSTER, PICKUP, VAN, COUPE, SUPERCAR, CABRIOLET;

}
