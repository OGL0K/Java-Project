package coursework_question2;

public enum CarType {
	
	MANUAL, AUTOMATIC;
}
