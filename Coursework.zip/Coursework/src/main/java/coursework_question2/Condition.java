package coursework_question2;

public enum Condition {
	
	NEW, USED;
}
