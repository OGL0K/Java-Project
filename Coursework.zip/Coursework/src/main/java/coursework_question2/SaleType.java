package coursework_question2;

public enum SaleType {

	FORSALE, AUCTION;
	
}
