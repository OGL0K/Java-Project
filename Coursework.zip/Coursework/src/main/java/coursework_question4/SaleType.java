package coursework_question4;

public enum SaleType {

	FORSALE, AUCTION;
	
}
