package coursework_question4;

public enum CarBody {


	MICRO, SEDAN, HATCHBACK, ROADSTER, PICKUP, VAN, COUPE, SUPERCAR, CABRIOLET;

}
